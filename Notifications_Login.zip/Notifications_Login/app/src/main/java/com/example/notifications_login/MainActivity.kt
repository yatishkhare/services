package com.example.notifications_login

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val username: EditText = findViewById(R.id.editTextEmailAddress)
        val password:EditText=  findViewById(R.id.editTextPassword)
        val login:Button= findViewById(R.id.btnLogin)
        val save: Button =findViewById(R.id.btnSave)


        sharedPreferences = getSharedPreferences("my_pref", Context.MODE_PRIVATE);
        login.setOnClickListener {
            print("Success")
            val name = sharedPreferences.getString("username",null)
            val Password= sharedPreferences.getString("password",null)

            if(username.text.toString() == name && password.text.toString() == Password)
            {
                val intent: Intent = Intent(this, NotificationsActivity::class.java)
                intent.putExtra("Name", name)
                startActivity(intent)
                finish()


            }  else{
                Toast.makeText(this,"Invalid Input",Toast.LENGTH_SHORT).show()
            }
        }
        save.setOnClickListener {
            val name:String = username.text.toString()
            val pwd:String= password.text.toString()

            val editor: SharedPreferences.Editor = sharedPreferences.edit()
            editor.putString("username", name)
            editor.putString("password", pwd)
            editor.apply()

            Toast.makeText(this,"INFO SAVED",Toast.LENGTH_SHORT).show()
        }

    }



}