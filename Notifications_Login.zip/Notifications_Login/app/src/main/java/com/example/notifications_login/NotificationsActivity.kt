package com.example.notifications_login


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class NotificationsActivity : AppCompatActivity() {
    lateinit var result: TextView
    lateinit var notif: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notifications)
        result = findViewById(R.id.textViewResult)
        notif = findViewById(R.id.btnNotif)

        val i= intent.getStringExtra("Name")
        result.text=i

        notif.setOnClickListener {
            NotificationHelper(this, result.text.toString()).Notification()

            val hideKeyboard = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            hideKeyboard.hideSoftInputFromWindow(currentFocus?.windowToken,0)

            Toast.makeText(this, "${result.text} is Sent", Toast.LENGTH_SHORT).show()

            Intent(this, SampleService::class.java).also { intent ->
                startService(intent)
            }

        }

    }
}